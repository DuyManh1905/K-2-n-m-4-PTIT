import {ReduxHelper} from '../../helpers';

export const prefix = 'AUTHENTICATION';

export const setAccountNumber = ReduxHelper.generateLocalAction<string>(
  prefix,
  'SET_ACCOUNT_NUMBER',
);
export const setInitAccessToken = ReduxHelper.generateLocalAction<string>(
  prefix,
  'INIT_ACCESS_TOKEN',
);

export const setIsAdmin = ReduxHelper.generateLocalAction<boolean>(
  prefix,
  'SET_IS_ADMIN',
);

export const logout = ReduxHelper.generateActions<undefined>(prefix, 'LOGOUT');
