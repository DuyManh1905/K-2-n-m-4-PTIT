import { ReduxHelper } from "../../helpers";
import { Device } from "../../model/Device";
import { Way } from "../../model/Way";

export const prefix = "USER";

export const setListDevice = ReduxHelper.generateLocalAction<Device[]>(
  prefix,
  "SET_LIST_DEVICE"
);

export const setWays = ReduxHelper.generateLocalAction<Way[]>(
  prefix,
  "SET_WAYS"
);
