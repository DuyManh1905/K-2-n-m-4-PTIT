import { createReducer, PayloadAction } from "@reduxjs/toolkit";
import {
  IBaseReducerState,
  createHandleReducer,
} from "../../helpers/reduxHelpers";
import { UserActions } from "../actions";
import { Device } from "../../model/Device";
import { Way } from "../../model/Way";
interface IUserState extends IBaseReducerState {
  listDevice: Device[];
  listWay: Way[];
}

const initialState: IUserState = {
  listDevice: [],
  listWay: [],
};

const setListDevice = (state: IUserState, action: PayloadAction<Device[]>) => {
  state.listDevice = action.payload;
};
const setListWay = (state: IUserState, action: PayloadAction<Way[]>) => {
  state.listWay = action.payload;
};

const UserReducer = createHandleReducer(initialState, (builder) => {
  builder
    .addCase(UserActions.setListDevice.request, setListDevice)
    .addCase(UserActions.setWays.request, setListWay);
});

export default UserReducer;
