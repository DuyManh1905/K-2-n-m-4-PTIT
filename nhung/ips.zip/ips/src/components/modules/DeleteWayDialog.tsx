import { StyleSheet, TouchableOpacity, View } from "react-native";
import { HookHelper, Mixin } from "../../helpers";
import { Image, Overlay } from "react-native-elements";
import AppText from "../atoms/AppText";
import { images } from "../../../assets";
import { theme } from "../../utils/styles/theme";
import { useAppSelector } from "../../helpers/hookHelper";
import { UserActions } from "../../stores/actions";

export const DeleteWayDialog = ({
  isVisible,
  setIsVisible,
  way,
}: any) => {
  const { theme, dispatch } = HookHelper.useBaseHook();
  const userReducer = useAppSelector((state) => state.UserReducer);


  const deleteWay = () => {
    const newListWay = userReducer.listWay.filter(
      (item) => (item.start !== way.start || item.end !== way.end)
    );

    dispatch(UserActions.setWays.request(newListWay));
    setIsVisible(false);

  }
  
  return (
    <Overlay
      isVisible={isVisible}
      onBackdropPress={() => setIsVisible(false)}
      overlayStyle={styles.modalContent}
    >
      <View>
        <View style={styles.titleContainer}>
          <AppText style={styles.title}>Xóa cung</AppText>
        </View>
        <View style={styles.container}>
          <AppText body1 style={styles.textAlign}>
            Bạn có chắc muốn xóa cung số {way.start}, {way.end} này không?
          </AppText>
        </View>
        <View style={styles.rowContainer}>
          <TouchableOpacity style={styles.btnContainer} onPress={() => deleteWay()}>
            <AppText>Xóa</AppText>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.btnContainer}
            onPress={() => setIsVisible(false)}
          >
            <AppText>Hủy</AppText>
          </TouchableOpacity>
        </View>
      </View>
    </Overlay>
  );
};

const styles = StyleSheet.create({
  modalContent: {
    backgroundColor: theme.colors?.primary,
    borderRadius: Mixin.moderateSize(10),
    width: "85%",
  },
  container: {
    backgroundColor: theme.colors?.white,
    borderWidth: 1,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: Mixin.moderateSize(10),
    paddingHorizontal: Mixin.moderateSize(20),
    paddingVertical: Mixin.moderateSize(10),
  },
  titleContainer: {
    backgroundColor: theme.colors?.white,
    borderRadius: Mixin.moderateSize(10),
    borderWidth: 1,
    justifyContent: "center",
    alignItems: "center",
    width: "50%",
    height: Mixin.moderateSize(40),
    bottom: Mixin.moderateSize(30),
    alignSelf: "center",
  },
  title: {
    fontSize: Mixin.moderateSize(20),
    fontWeight: "500",
  },
  icon: {
    width: Mixin.moderateSize(50),
    height: Mixin.moderateSize(50),
    alignSelf: "center",
    margin: Mixin.moderateSize(20),
  },
  textAlign: {
    textAlign: "center",
    marginBottom: Mixin.moderateSize(10),
  },
  rowContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginTop: Mixin.moderateSize(20),
  },
  btnContainer: {
    backgroundColor: theme.colors?.white,
    borderRadius: Mixin.moderateSize(10),
    borderWidth: 1,
    justifyContent: "center",
    alignItems: "center",
    height: Mixin.moderateSize(35),
    width: "45%",
  },
});
