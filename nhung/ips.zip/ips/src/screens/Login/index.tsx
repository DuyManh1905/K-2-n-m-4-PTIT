import React, { useState } from "react";
import { View } from "react-native";

import AppInput from "../../components/atoms/AppInput";
import AppText from "../../components/atoms/AppText";
import AppButton from "../../components/atoms/Button";
import { ErrorModal } from "../../components/atoms/ErrorModal";
import { HookHelper } from "../../helpers";
import { useGetNavigation } from "../../helpers/hookHelper";
import { AuthenticationActions, UserActions } from "../../stores/actions";
import useStyles from "./styles";

export const LoginScreen = () => {
  const { theme, dispatch } = HookHelper.useBaseHook();
  const { navigation } = useGetNavigation();

  const [phoneString, setPhoneString] = useState("");
  const [passwordString, setPasswordString] = useState("");
  const [savePassword, setSavePassword] = useState(false);
  const styles = useStyles(theme);
  const [showError, setShowError] = useState(false);
  const [error, setError] = useState<{ title: string; description?: string }>();
  const onNext = async () => {
    if (phoneString == "" || passwordString == "") {
      setError({
        title: "Lỗi",
        description: "Vui lòng nhập đầy đủ thông tin",
      });
      setShowError(true);
      return;
    }
    if (phoneString == "admin" && passwordString == "admin") {
      dispatch(AuthenticationActions.setIsAdmin.request(true));
    } else {
      dispatch(AuthenticationActions.setIsAdmin.request(false));
    }
    dispatch(AuthenticationActions.setAccountNumber.request(phoneString));

    dispatch(
      UserActions.setListDevice.request([
        {
          id: 1,
          x: 240,
          y: 670,
          mac: "80:EA:CA:00:00:01",
          rssi: -10,
          title: "Hồ Văn",
          description: "Xây dựng năm 1070, thời Lý.\nHồ nước lớn nhất Văn Miếu",
        },
        {
          id: 2,
          x: 305,
          y: 633,
          mac: "80:EA:CA:00:00:02",
          rssi: -20,
          title: "Bia Hà Mã",
          description: "Bia Hà Mã, bia đầu tiên của Văn Miếu.\nXây dựng năm 1070, thời Lý.",
        },
        {
          id: 3,
          x: 171,
          y: 632,
          mac: "34:22:53:11:66:44",
          rssi: -20,
          title: "Bia Hà Mã",
          description: "Bia Hà Mã, bia đầu tiên của Văn Miếu.\nXây dựng năm 1070, thời Lý.",
        },
        {
          id: 4,
          x: 235,
          y: 614,
          mac: "80:EA:CA:00:00:03",
          rssi: -30,
          title: "Tứ trụ",
        },
        {
          id: 5,
          x: 237,
          y: 586,
          mac: "80:EA:CA:00:00:05",
          rssi: -50,
          title: "Cổng Văn Miếu",
        },
        {
          id: 6,
          x: 235,
          y: 454,
          mac: "80:EA:CA:00:00:05",
          rssi: -50,
          title: "Cổng Đại Trung",
        },
        {
          id: 7,
          x: 105,
          y: 450,
          mac: "80:EA:CA:00:00:04",
          rssi: -40,
          title: "Vườn Giám",
        },

        {
          id: 8,
          x: 233,
          y: 371,
          mac: "80:EA:CA:00:00:05",
          rssi: -50,
          title: "Khuê Văn Các",
        },
        {
          id: 9,
          x: 236,
          y: 311,
          mac: "80:EA:CA:00:00:05",
          rssi: -50,
          title: "Giếng Thiên Quang",
        },
        {
          id: 10,
          x: 284,
          y: 335,
          mac: "80:EA:CA:00:00:05",
          rssi: -50,
          title: "Bia Tiến Sĩ",
        },
        {
          id: 11,
          x: 189,
          y: 336,
          mac: "80:EA:CA:00:00:05",
          rssi: -50,
          title: "Bia Tiến Sĩ",
        },
        {
          id: 12,
          x: 191,
          y: 280,
          mac: "80:EA:CA:00:00:05",
          rssi: -50,
          title: "Bia Tiến Sĩ",
        },
        {
          id: 13,
          x: 280,
          y: 280,
          mac: "80:EA:CA:00:00:05",
          rssi: -50,
          title: "Bia Tiến Sĩ",
        },
        {
          id: 14,
          x: 231,
          y: 270,
          mac: "80:EA:CA:00:00:05",
          rssi: -50,
          title: "Cổng Đại Thành",
        },
        {
          id: 15,
          x: 233,
          y: 211,
          mac: "80:EA:CA:00:00:05",
          rssi: -50,
          title: "Khu Đại Thành",
        },
        {
          id: 16,
          x: 230,
          y: 139,
          mac: "80:EA:CA:00:00:05",
          rssi: -50,
          title: "Cổng Thái Học",
        },
        {
          id: 17,
          x: 300,
          y: 36,
          mac: "80:EA:CA:00:00:05",
          rssi: -50,
          title: "Lầu Trống",
        },
        {
          id: 18,
          x: 174,
          y: 47,
          mac: "80:EA:CA:00:00:05",
          rssi: -50,
          title: "Lầu Chuông",
        },
        {
          id: 19,
          x: 230,
          y: 42,
          mac: "80:EA:CA:00:00:05",
          rssi: -50,
          title: "Khu Thái Học",
        },
      ])
    );
    dispatch(
      UserActions.setWays.request([
        {
          start: 1,
          end: 2,
        },
        {
          start: 2,
          end: 4,
        },
        {
          start: 4,
          end: 5,
        },
        {
          start: 6,
          end: 8,
        },
        {
          start: 7,
          end: 8,
        },
        {
          start: 8,
          end: 9,
        },
        {
          start: 9,
          end: 12,
        },
        {
          start: 9,
          end: 11,
        },
        {
          start: 9,
          end: 10,
        },
        {
          start: 9,
          end: 13,
        },
        {
          start: 12,
          end: 14,
        },
        {
          start: 14,
          end: 15,
        },
        {
          start: 15,
          end: 16,
        },
        {
          start: 16,
          end: 19,
        },
        {
          start: 1,
          end: 3,
        },
        {
          start: 5,
          end: 6,
        },
        {
          start: 19,
          end: 18,
        },
        {
          start: 19,
          end: 17,
        },
      ])
    );
  };
  const tryAgain = () => {
    setShowError(false);
    setError(undefined);
  };

  return (
    <View style={styles.container}>
      <View>
        <AppText style={styles.title}>Xin chào! 👋</AppText>
        <View style={styles.inputContainer}>
          <AppText style={styles.inputLabel}>Tên đăng nhập</AppText>
          <AppInput
            label={"Hãy nhập tên đăng nhập"}
            value={phoneString}
            onChangeText={(text) => setPhoneString(text)}
            containerStyles={styles.inputStyle}
          />
        </View>
        <View style={styles.inputContainer}>
          <AppText style={styles.inputLabel}>Mật khẩu</AppText>
          <AppInput
            label={"Hãy nhập mật khẩu"}
            value={passwordString}
            maxLength={100}
            isPassword
            keyboardType="default"
            onChangeText={(text) => setPasswordString(text)}
            containerStyles={styles.inputStyle}
          />
        </View>
      </View>
      {/* <View style={styles.rowView}>
        <View style={styles.rememberContainer}>
          <AppCheckBox
            isSelected={savePassword}
            setSelection={setSavePassword}
          />
          <AppText>Ghi nhớ đăng nhập</AppText>
        </View>
        <AppText style={styles.forgotText}>Quên mật khẩu</AppText>
      </View> */}
      <AppButton
        title={"Đăng nhập"}
        onPress={() => onNext()}
        customBtnStyle={styles.buttonStyle}
      />

      <ErrorModal
        confirmTitle={"Try again"}
        onConfirm={() => tryAgain()}
        isVisible={showError}
        title={error?.title || ""}
        description={error?.description}
      />
    </View>
  );
};
