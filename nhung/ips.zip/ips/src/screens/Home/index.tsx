import React from "react";
import { TouchableOpacity, View } from "react-native";
import AppText from "../../components/atoms/AppText";
import { HookHelper } from "../../helpers";
import useStyles from "./styles";
import { useAppSelector, useGetNavigation } from "../../helpers/hookHelper";
import { DrawerActions } from "@react-navigation/native";
import AppHeader from "../../components/atoms/Header";

export const HomeScreen = () => {
  const { theme, dispatch } = HookHelper.useBaseHook();
  const styles = useStyles(theme);
  const { navigation } = useGetNavigation();
  const authenticationReducer = useAppSelector(
    (state) => state.AuthenticationReducer
  );
  return (
    <View style={styles.container}>
      <AppHeader title="Danh sách tầng" />
      <View style={styles.content}>
        <TouchableOpacity
          onPress={() => {
            if (authenticationReducer.isAdmin) {
              navigation.navigate("Map");
            } else {
              navigation.navigate("MapUser");
            }
          }}
          style={styles.button}
        >
          <AppText white h5>
            Văn Miếu - Quốc Tử Giám
          </AppText>
        </TouchableOpacity>
      </View>
    </View>
  );
};
