import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Image,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from "react-native";
import { Circle, Line, Svg, Text } from "react-native-svg";
import { images } from "../../../assets";
import { PositionDialog } from "../../components/modules/PositionDialog";
import { HookHelper } from "../../helpers";
import { useAppSelector } from "../../helpers/hookHelper";
import { Device } from "../../model/Device";
import useStyles from "./styles";
import AppHeader from "../../components/atoms/Header";
import { Way } from "../../model/Way";
import { Icon } from "react-native-elements";
import { findPathDFS } from "../../helpers/pathHelper";
import AppText from "../../components/atoms/AppText";

const customAnimatedSequence = (animations: any, onStepStart: any) => {
  let current = 0;
  return {
    start: (callback: any) => {
      const onComplete = (result: any) => {
        if (!result.finished) {
          callback && callback(result);
          return;
        }

        current += 1;

        if (current === animations.length) {
          callback && callback(result);
          return;
        }

        onStepStart && onStepStart({ current });
        animations[current].start(onComplete);
      };

      if (animations.length === 0) {
        callback && callback({ finished: true });
      } else {
        onStepStart && onStepStart({ current });
        animations[current].start(onComplete);
      }
    },

    stop: () => {
      if (current < animations.length) {
        animations[current].stop();
      }
    },

    reset: () => {
      animations.forEach((animation: any, idx: any) => {
        if (idx <= current) {
          animation.reset();
        }
      });
      current = 0;
    },

    _startNativeLoop: () => {
      throw new Error(
        "Loops run using the native driver cannot contain Animated.sequence animations"
      );
    },

    _isUsingNativeDriver: () => false,
  };
};
const AnimatedCircle = Animated.createAnimatedComponent(Circle);

export const MapUserScreen = () => {
  const { theme, dispatch } = HookHelper.useBaseHook();
  const { navigation, route } = HookHelper.useGetNavigation<"MapUser">();
  const styles = useStyles(theme);
  const userReducer = useAppSelector((state) => state.UserReducer);
  const [showTooltip, setShowTooltip] = useState(false);
  const [tooltipPosition, setTooltipPosition] = useState<Device>();
  const [currentNode, setCurrentNode] = useState<Device[]>([]);
  const [currentWay, setCurrentWay] = useState<Way[]>([]);

  const position = useRef(new Animated.ValueXY({ x: 240, y: 670 })).current;
  let sequence: any;
  useEffect(() => {
    if (route.params?.device) {
      const device = route.params.device;
      const startNode = 1;
      const endNode = device.id;
      const visited = new Array(userReducer.listDevice.length).fill(false);
      const pathDFS = findPathDFS(
        startNode,
        endNode,
        visited,
        [],
        userReducer.listWay
      );
      const result = [];

      for (let i = 0; i < pathDFS.length - 1; i++) {
        result.push({
          start: pathDFS[i],
          end: pathDFS[i + 1],
        });
      }

      const nodes = pathDFS.map(
        (item: number) => userReducer.listDevice[item - 1]
      );

      setCurrentWay(result);
      setCurrentNode(nodes);

      // loop throuth pathDFS
      // get the start and end node
      // get the start and end node coordinate
      const animataionSequence = pathDFS.map((item: any, index: any) => {
        return Animated.timing(position, {
          toValue: {
            x: userReducer.listDevice[item - 1].x,
            y: userReducer.listDevice[item - 1].y,
          },
          duration: 10000,
          useNativeDriver: true,
        });
      });
      // Animated.sequence(animataionSequence).start();
      sequence = customAnimatedSequence(
        animataionSequence,
        ({ current }: any) => {
          setTimeout(() => {
            setShowTooltip(true);
            setTooltipPosition(userReducer.listDevice[pathDFS[current] - 1]);
          }, 9000);
          setTimeout(() => {
            setShowTooltip(false);
          }, 10000);
        }
      );
      sequence.start(() => {});
    }
  }, [route]);

  const handleCircleClick = (item: Device) => {
    setShowTooltip(true);
    setTooltipPosition(item);
  };

  const handleTooltipClose = () => {
    setShowTooltip(false);
  };
  return (
    <View style={styles.container}>
      <AppHeader
        title="Bản đồ văn miếu"
        hideBack
        filled
        textStyles={{ color: "white" }}
        rightComponent={
          <TouchableOpacity onPress={() => navigation.navigate("MapSearch")}>
            <Icon name="magnify" size={30} color={"white"} />
          </TouchableOpacity>
        }
      />
      <TouchableWithoutFeedback onPress={() => handleTooltipClose()}>
        <View style={styles.content}>
          <Image source={images.map} style={styles.image} />
          {showTooltip && (
            <View style={[styles.tooltipContainer]}>
              <AppText>{tooltipPosition?.title}</AppText>
              <AppText>{tooltipPosition?.description}</AppText>
            </View>
          )}
          <Svg style={styles.svgStyle}>
            {currentWay.map((item, index) => {
              return (
                <Line
                  key={index}
                  x1={userReducer?.listDevice[item.start - 1].x}
                  y1={userReducer?.listDevice[item.start - 1].y}
                  x2={userReducer?.listDevice[item.end - 1].x}
                  y2={userReducer?.listDevice[item.end - 1].y}
                  strokeWidth={2}
                  stroke={theme.colors?.primary}
                />
              );
            })}
            {currentNode.map((item, index) => {
              return (
                <View key={index}>
                  <Circle
                    cx={item.x}
                    cy={item.y}
                    r={10}
                    fill={theme.colors?.primary}
                    onPress={() => handleCircleClick(item)}
                  />
                  <Text
                    x={item.x}
                    y={item.y}
                    textAnchor="middle"
                    fontSize={10}
                    alignmentBaseline="middle"
                    fill="white"
                  >
                    {item.id}
                  </Text>
                </View>
              );
            })}
            <AnimatedCircle
              cx={position.x}
              cy={position.y}
              r={10}
              fill={"red"}
            />
          </Svg>
          {/* <PositionDialog
          isVisible={showTooltip}
          setIsVisible={handleTooltipClose}
          device={tooltipPosition!}
        /> */}
        
        </View>
      </TouchableWithoutFeedback>
    </View>
  );
};
