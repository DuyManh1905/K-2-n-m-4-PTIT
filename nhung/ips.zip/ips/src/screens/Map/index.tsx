import React, { useState } from "react";
import { Image, View } from "react-native";
import { Circle, Line, Svg, Text } from "react-native-svg";
import { images } from "../../../assets";
import { PositionDialog } from "../../components/modules/PositionDialog";
import { HookHelper } from "../../helpers";
import { useAppSelector } from "../../helpers/hookHelper";
import { Device } from "../../model/Device";
import useStyles from "./styles";
import AppHeader from "../../components/atoms/Header";

export const MapScreen = () => {
  const { theme, dispatch } = HookHelper.useBaseHook();
  const { navigation } = HookHelper.useGetNavigation();
  const styles = useStyles(theme);
  const userReducer = useAppSelector((state) => state.UserReducer);
  const [showTooltip, setShowTooltip] = useState(false);
  const [tooltipPosition, setTooltipPosition] = useState<Device>();

  const handleCircleClick = (item: Device) => {
    setShowTooltip(true);
    setTooltipPosition(item);
  };

  const handleTooltipClose = () => {
    setShowTooltip(false);
  };

  const getDeviceById = (id: number) => {
    return userReducer?.listDevice.find((item) => item.id == id);
  }

  return (
    <View style={styles.container}>
      <AppHeader
        title="Bản đồ văn miếu"
        hideBack
        filled
        textStyles={{ color: "white" }}
        
      />
      <View style={styles.content}>
        <Image source={images.map} style={styles.image} />

        <Svg style={styles.svgStyle}>
          {userReducer?.listWay.map((item, index) => {
            return (
              <Line
                key={index}
                x1={getDeviceById(item.start)!.x}
                y1={getDeviceById(item.start)!.y}
                x2={getDeviceById(item.end)!.x}
                y2={getDeviceById(item.end)!.y}
                strokeWidth={2}
                stroke={theme.colors?.primary}
              />
            );
          })}
          {userReducer?.listDevice.map((item, index) => {
            return (
              <View key={index}>
                <Circle
                  cx={item.x}
                  cy={item.y}
                  r={10}
                  fill={theme.colors?.primary}
                  onPress={() => handleCircleClick(item)}
                />
                <Text
                  x={item.x}
                  y={item.y}
                  textAnchor="middle"
                  fontSize={10}
                  alignmentBaseline="middle"
                  fill="white"
                >
                  {item.id}
                </Text>
              </View>
            );
          })}
        </Svg>
        <PositionDialog
          isVisible={showTooltip}
          setIsVisible={handleTooltipClose}
          device={tooltipPosition!}
        />
      </View>
    </View>
  );
};
