import { makeStyles } from "react-native-elements";
import { Mixin } from "../../helpers";

export default makeStyles((theme) => ({
  container: {
    height: "100%",
    alignItems: "center",
    backgroundColor: "white",
  },
  image: {
    width: "100%",
    height: "100%",
  },
  svgStyle: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  tooltipContainer: {
    backgroundColor: "white",
    padding: 10,
  },
  content: {
    flex: 1,
    width: "100%",
    height: "100%",
  },
}));
