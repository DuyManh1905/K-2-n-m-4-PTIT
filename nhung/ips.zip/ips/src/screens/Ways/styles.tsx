import { makeStyles } from "react-native-elements";
import { Mixin } from "../../helpers";

export default makeStyles((theme) => ({
  container: {
    justifyContent: "center",
    height: "100%",
  },
  pointItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "white",
    padding: Mixin.moderateSize(16),
    borderRadius: Mixin.moderateSize(10),
    marginVertical: Mixin.moderateSize(8),
  },
  indexContainer: {
    backgroundColor: theme.colors?.primary,
    width: Mixin.moderateSize(40),
    height: Mixin.moderateSize(40),
    justifyContent: "center",
    alignItems: "center",
    borderRadius: Mixin.moderateSize(20),
  },
  adddBtn: {
    backgroundColor: theme.colors?.primary,
    width: Mixin.moderateSize(50),
    height: Mixin.moderateSize(50),
    justifyContent: "center",
    alignItems: "center",
    borderRadius: Mixin.moderateSize(25),
    position: "absolute",
    bottom: Mixin.moderateSize(16),
    alignSelf: "center",
    zIndex: 1,
  },
  rowContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  icon: {
    marginHorizontal: Mixin.moderateSize(8),
  },
  content: {
    paddingHorizontal: Mixin.moderateSize(16),
    paddingTop: Mixin.moderateSize(16),
    height: "100%",
    width: "100%",
    flex: 1,
  },
}));
