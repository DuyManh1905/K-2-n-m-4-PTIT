import React from "react";
import { Image, TouchableOpacity, View } from "react-native";
import { HookHelper } from "../../helpers";
import useStyles from "./styles";
import { images } from "../../../assets";
import AppText from "../../components/atoms/AppText";
import AppButton from "../../components/atoms/Button";

export const SplashScreen = () => {
  const { theme, dispatch } = HookHelper.useBaseHook();
  const { navigation } = HookHelper.useGetNavigation();
  const styles = useStyles(theme);

  return (
    <View style={styles.container}>
      <Image source={images.appIcon} style={styles.image} />
      <AppText style={styles.description}>
        Hệ thống định vị du lịch sử dụng BLE
      </AppText>
      <AppButton
        title={"Bắt đầu sử dụng"}
        onPress={() => navigation.navigate("Login")}
      />

      <View style={styles.rowContainer}>
        <AppText>Bạn là admin ? </AppText>
        <TouchableOpacity onPress={() => {}}>
          <AppText>Đăng nhập ngay</AppText>
        </TouchableOpacity>
      </View>
    </View>
  );
};
