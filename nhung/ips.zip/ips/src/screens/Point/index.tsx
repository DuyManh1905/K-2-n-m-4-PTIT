import React from "react";
import { FlatList, TouchableOpacity, View } from "react-native";
import { HookHelper } from "../../helpers";
import useStyles from "./styles";
import AppText from "../../components/atoms/AppText";
import { Icon, Switch } from "react-native-elements";
import { useAppSelector } from "../../helpers/hookHelper";
import { AddDeviceDialog } from "../../components/modules/AddDeviceDialog";
import { DeleteDeviceDialog } from "../../components/modules/DeleteDeviceDialog";
import AppHeader from "../../components/atoms/Header";

const PointItem = ({ item, index }: any) => {
  const { theme, dispatch } = HookHelper.useBaseHook();
  const styles = useStyles(theme);
  const [isEnabled, setIsEnabled] = React.useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = React.useState(false);

  return (
    <View style={styles.pointItem}>
      <View style={styles.indexContainer}>
        <AppText white>#{item.id}</AppText>
      </View>
      <View>
        <AppText>
          X={item.x}, Y={item.y}
        </AppText>
        <AppText>MAC: {item.mac}</AppText>
        <AppText>RSSI 1m: {item.rssi}</AppText>
      </View>
      <Switch
        value={isEnabled}
        onValueChange={() => setIsEnabled(!isEnabled)}
        trackColor={{ false: "#767577", true: "#81b0ff" }}
      />
      <TouchableOpacity onPress={() => setShowDeleteDialog(true)}>
        <Icon name="delete" color={"red"} />
      </TouchableOpacity>
      <DeleteDeviceDialog
        isVisible={showDeleteDialog}
        setIsVisible={setShowDeleteDialog}
        device={item}
      />
    </View>
  );
};

export const PointScreen = () => {
  const { theme, dispatch } = HookHelper.useBaseHook();
  const styles = useStyles(theme);
  const userReducer = useAppSelector((state) => state.UserReducer);
  const [showAddDialog, setShowAddDialog] = React.useState(false);

  return (
    <View style={styles.container}>
      <AppHeader title="Danh sách beacons" />
      <View style={styles.content}>
        <FlatList
          data={userReducer?.listDevice}
          renderItem={({ item, index }) => (
            <PointItem item={item} index={index} />
          )}
          keyExtractor={(item, index) => index.toString()}
        />
        <TouchableOpacity
          style={styles.adddBtn}
          onPress={() => setShowAddDialog(true)}
        >
          <Icon name="plus" color={"white"} size={30} />
        </TouchableOpacity>
        <AddDeviceDialog
          isVisible={showAddDialog}
          setIsVisible={setShowAddDialog}
        />
      </View>
    </View>
  );
};
