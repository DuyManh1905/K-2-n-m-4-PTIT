export const findPathDFS = (start: any, end: any, visited: any, path: any, edges: any) => {
    visited[start - 1] = true;
    path.push(start);
  
    if (start === end) {
      return path;
    }
  
    for (const edge of edges) {
      if (edge.start === start && !visited[edge.end - 1]) {
        const newPath: any = findPathDFS(edge.end, end, visited, path, edges);
        if (newPath.length > 0) {
          return newPath;
        }
      }
    }
  
    path.pop();
    return [];
  }