import {
  NavigationContainer,
  useNavigationContainerRef,
} from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import React from "react";
import { RouteParamList } from "./RouteParamList";
import { HomeScreen } from "../screens/Home";
import { MapScreen } from "../screens/Map";
import { MapUserScreen } from "../screens/MapUser";
import { MapSearchScreen } from "../screens/MapSearch";

const Stack = createNativeStackNavigator<RouteParamList>();

export const HomeRoute = () => {
  const navigationRef = useNavigationContainerRef<any>();

  return (
    <Stack.Navigator
      // initialRouteName="MyQr"
      screenOptions={{ headerShown: false }}
    >
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="Map" component={MapScreen} />
      <Stack.Screen name="MapUser" component={MapUserScreen} />
      <Stack.Screen name="MapSearch" component={MapSearchScreen} />

    </Stack.Navigator>
  );
};
