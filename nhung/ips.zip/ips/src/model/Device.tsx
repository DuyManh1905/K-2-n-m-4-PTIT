export interface Device {
    id: number;
    x: number;
    y: number;
    mac: string;
    rssi: number;
    title: string;
    description?: string;
}
