export interface Way {
   start: number;
    end: number;
}
