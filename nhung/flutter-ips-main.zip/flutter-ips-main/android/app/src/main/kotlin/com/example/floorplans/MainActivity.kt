package com.example.floorplans

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
