class Anchor {
  double centerX;
  double centerY;
  double radius;

  Anchor({required this.centerX, required this.centerY, required this.radius});
}
