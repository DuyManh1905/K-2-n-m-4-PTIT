import 'package:flutter/material.dart';

abstract class BaseElement {
  Rect getExtent();
}
