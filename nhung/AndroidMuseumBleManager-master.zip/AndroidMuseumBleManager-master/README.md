
# Android Museum BLE Manager

An Android Application for in-museum localisation and interaction with the actifacts in the museum. Realised by receiving signal from presetted iBeacon clusters in the museum. 

###### Originally a fork from [haodynasty/AndroidBleManager](https://github.com/haodynasty/AndroidBleManager) started by [meng96163004](https://github.com/meng96163004)
###### Library used: [AndroidBleManager](https://github.com/haodynasty/AndroidBleManager)
