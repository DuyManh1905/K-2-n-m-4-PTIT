package com.androidbeaconedmuseum;

/**
 * Created by toy on 15/06/2017.
 */

public class ArtworkNotFoundException extends Throwable {
}
