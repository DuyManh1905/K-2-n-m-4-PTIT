package com.androidbeaconedmuseum;

/**
 * Created by toy on 05/06/2017.
 */

public class BeaconUnrecognisedException extends Exception {
}
