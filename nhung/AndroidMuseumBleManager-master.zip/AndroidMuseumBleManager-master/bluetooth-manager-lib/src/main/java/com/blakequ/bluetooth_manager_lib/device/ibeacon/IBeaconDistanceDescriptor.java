package com.blakequ.bluetooth_manager_lib.device.ibeacon;

public enum IBeaconDistanceDescriptor {
    IMMEDIATE,
    NEAR,
    FAR,
    UNKNOWN,
}
