package com.blakequ.bluetooth_manager_lib.device;

/**
 *
 */
public interface BeaconDevice {
    BeaconType getBeaconType();
}
