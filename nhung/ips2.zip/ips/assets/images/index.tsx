
export const closeIcon = require("./icon-close.png");
export const error = require("./error.png");


export const appIcon = require("./appicon.png");
export const menuBg = require("./menu-bg.jpeg");
export const userProfile = require("./user-profile.jpg");
export const map = require("./map.jpg");