
import * as images from './images/index';

export {images};
