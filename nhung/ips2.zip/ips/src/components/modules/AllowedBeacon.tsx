import React, { useState, useEffect } from 'react';
import { Text, View } from 'react-native';
import * as Location from 'expo-location';
import * as Bluetooth from 'expo-bluetooth';

const ALLOWED_BEACONS = ['your_beacon_uuid_1', 'your_beacon_uuid_2']; // Thay thế bằng các UUID của beacon bạn muốn cho phép kết nối

const BeaconDistanceCalculator = () => {
  const [distances, setDistances] = useState({});

  useEffect(() => {
    const calculateDistances = async () => {
      try {
        // Lấy vị trí hiện tại của thiết bị
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') {
          console.error('Permission to access location was denied');
          return;
        }
        const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Highest });

        // Lấy khoảng cách từ thiết bị đến các beacon được phép
        const newDistances = {};
        for (const beaconUUID of ALLOWED_BEACONS) {
          const { distance } = await Bluetooth.getDistanceAsync(beaconUUID);
          newDistances[beaconUUID] = distance;
        }
        setDistances(newDistances);
      } catch (error) {
        console.error('Error calculating distances:', error);
      }
    };

    calculateDistances();

    // Cập nhật khoảng cách mỗi 5 giây
    const interval = setInterval(calculateDistances, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <View>
      {ALLOWED_BEACONS.map((beaconUUID, index) => (
        <View key={index}>
          <Text>Beacon UUID: {beaconUUID}</Text>
          <Text>Distance: {distances[beaconUUID]} meters</Text>
        </View>
      ))}
    </View>
  );
};

export default BeaconDistanceCalculator;