import React, { useState, useEffect } from "react";
import { Text, View } from "react-native";
import * as Location from "expo-location";
import * as Bluetooth from "expo-bluetooth";

const BeaconLocation = ({ beacons }) => {
  const [distances, setDistances] = useState({});

  useEffect(() => {
    const calculateDistances = async () => {
      try {
        // Lấy vị trí hiện tại của thiết bị
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== "granted") {
          console.error("Permission to access location was denied");
          return;
        }
        const location = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.Highest,
        });

        // Lấy khoảng cách từ thiết bị đến các beacon
        const newDistances = {};
        for (const beacon of beacons) {
          if (!newDistances[beacon.uuid]) {
            const { distance } = await Bluetooth.getDistanceAsync(beacon.uuid);
            newDistances[beacon.uuid] = { distance, lastUpdate: Date.now() };
          } else {
            // Nếu beacon đã được cập nhật trong vòng 5 giây trước đó, bỏ qua
            if (Date.now() - newDistances[beacon.uuid].lastUpdate < 5000)
              continue;
            const { distance } = await Bluetooth.getDistanceAsync(beacon.uuid);
            newDistances[beacon.uuid] = { distance, lastUpdate: Date.now() };
          }
        }
        setDistances(newDistances);
      } catch (error) {
        console.error("Error calculating distances:", error);
      }
    };

    calculateDistances();

    // Cập nhật khoảng cách mỗi 5 giây
    const interval = setInterval(calculateDistances, 5000);

    return () => clearInterval(interval);
  }, [beacons]);

  return (
    <View>
      {beacons.map((beacon, index) => (
        <View key={index}>
          <Text>Beacon UUID: {beacon.uuid}</Text>
          <Text>Distance: {distances[beacon.uuid]?.distance} meters</Text>
        </View>
      ))}
    </View>
  );
};

export default BeaconLocation;
