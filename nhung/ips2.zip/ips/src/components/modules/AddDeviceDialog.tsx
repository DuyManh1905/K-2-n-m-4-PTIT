import { StyleSheet, TouchableOpacity, View } from "react-native";
import { HookHelper, Mixin } from "../../helpers";
import { Image, Overlay } from "react-native-elements";
import AppText from "../atoms/AppText";
import { images } from "../../../assets";
import { theme } from "../../utils/styles/theme";
import React, { useState } from "react";
import AppInput from "../atoms/AppInput";
import { useAppSelector } from "../../helpers/hookHelper";
import { UserActions } from "../../stores/actions";

export const AddDeviceDialog = ({ isVisible, setIsVisible }: any) => {
  const [xCor, setXCor] = useState("");
  const [yCor, setYCor] = useState("");
  const [mac, setMac] = useState("");
  const [rssi, setRssi] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const { theme, dispatch } = HookHelper.useBaseHook();
  const userReducer = useAppSelector((state) => state.UserReducer);

  const addDevice = () => {
    const newListDevice = [
      ...userReducer.listDevice,
      {
        id: userReducer.listDevice.length + 1,
        x: parseInt(xCor),
        y: parseInt(yCor),
        mac: mac,
        rssi: parseInt(rssi),
        title: title,
        description: description,
      },
    ];

    dispatch(UserActions.setListDevice.request(newListDevice));
    setIsVisible(false);
  };

  return (
    <Overlay
      isVisible={isVisible}
      onBackdropPress={() => setIsVisible(false)}
      overlayStyle={styles.modalContent}
    >
      <View>
        <View style={styles.titleContainer}>
          <AppText style={styles.title}>Thêm beacon</AppText>
        </View>
        <View style={styles.container}>
          <AppInput
            label={"X"}
            value={xCor}
            onChangeText={(text) => setXCor(text)}
            containerStyles={styles.inputStyle}
          />
          <AppInput
            label={"Y"}
            value={yCor}
            onChangeText={(text) => setYCor(text)}
            containerStyles={styles.inputStyle}
          />
          <AppInput
            label={"MAC"}
            value={mac}
            onChangeText={(text) => setMac(text)}
            containerStyles={styles.inputStyle}
          />
          <AppInput
            label={"RSSI"}
            value={rssi}
            onChangeText={(text) => setRssi(text)}
            containerStyles={styles.inputStyle}
          />
          <AppInput
            label={"Tiêu đề"}
            value={title}
            onChangeText={(text) => setTitle(text)}
            containerStyles={styles.inputStyle}
          />
          <AppInput
            label={"Chú thích"}
            value={description}
            onChangeText={(text) => setDescription(text)}
            containerStyles={styles.inputStyle}
          />
          <View style={styles.rowContainer}>
            <TouchableOpacity
              style={styles.btnContainer}
              onPress={() => addDevice()}
            >
              <AppText h5 white>
                Thêm
              </AppText>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.btnContainer}
              onPress={() => setIsVisible(false)}
            >
              <AppText h5 white>
                Hủy
              </AppText>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Overlay>
  );
};

const styles = StyleSheet.create({
  modalContent: {
    backgroundColor: theme.colors?.primary,
    borderRadius: Mixin.moderateSize(10),
    width: "85%",
  },
  container: {
    backgroundColor: theme.colors?.white,
    borderWidth: 1,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: Mixin.moderateSize(10),
    paddingHorizontal: Mixin.moderateSize(20),
    paddingBottom: Mixin.moderateSize(10),
  },
  titleContainer: {
    backgroundColor: theme.colors?.white,
    borderRadius: Mixin.moderateSize(10),
    borderWidth: 1,
    justifyContent: "center",
    alignItems: "center",
    width: "50%",
    height: Mixin.moderateSize(40),
    bottom: Mixin.moderateSize(30),
    alignSelf: "center",
  },
  title: {
    fontSize: Mixin.moderateSize(20),
    fontWeight: "500",
  },
  icon: {
    width: Mixin.moderateSize(50),
    height: Mixin.moderateSize(50),
    alignSelf: "center",
    margin: Mixin.moderateSize(20),
  },
  textAlign: {
    textAlign: "center",
    marginBottom: Mixin.moderateSize(10),
  },
  rowContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginTop: Mixin.moderateSize(30),
    width: "100%",
  },
  btnContainer: {
    backgroundColor: theme.colors?.primary,
    borderRadius: Mixin.moderateSize(10),
    borderWidth: 1,
    justifyContent: "center",
    alignItems: "center",
    height: Mixin.moderateSize(35),
    width: "45%",
  },
  inputStyle: {
    marginTop: Mixin.moderateSize(16),
  },
});
