// import React, { useState, useEffect } from 'react';
// import { Text, View } from 'react-native';
// import * as Location from 'expo-location';
// import * as Bluetooth from 'expo-bluetooth';

// const BeaconDistanceCalculator = ({ beacon }) => {
//   const [distance, setDistance] = useState(null);

//   useEffect(() => {
//     const calculateDistance = async () => {
//       try {
//         // Lấy vị trí hiện tại của thiết bị
//         const { status } = await Location.requestForegroundPermissionsAsync();
//         if (status !== 'granted') {
//           console.error('Permission to access location was denied');
//           return;
//         }
//         const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Highest });

//         // Lấy thông tin về beacon
//         const { distance } = await Bluetooth.getDistanceAsync(beacon.uuid);
//         setDistance(distance);
//       } catch (error) {
//         console.error('Error calculating distance:', error);
//       }
//     };

//     calculateDistance();

//     // Cập nhật khoảng cách mỗi 5 giây
//     const interval = setInterval(calculateDistance, 5000);

//     return () => clearInterval(interval);
//   }, [beacon]);

//   return (
//     <View>
//       <Text>Beacon UUID: {beacon.uuid}</Text>
//       <Text>Distance: {distance} meters</Text>
//     </View>
//   );
// };

// export default BeaconDistanceCalculator;