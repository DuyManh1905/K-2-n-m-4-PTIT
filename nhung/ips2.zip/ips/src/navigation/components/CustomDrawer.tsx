import React from "react";
import {
  View,
  Text,
  ImageBackground,
  Image,
  TouchableOpacity,
} from "react-native";
import {
  DrawerContentScrollView,
  DrawerItemList,
} from "@react-navigation/drawer";

import Ionicons from "react-native-vector-icons/Ionicons";
import FontAwesome5 from "react-native-vector-icons/FontAwesome5";
import { images } from "../../../assets";
import { HookHelper } from "../../helpers";
import { AuthenticationActions } from "../../stores/actions";

const CustomDrawer = (props: any) => {
  const { theme, dispatch } = HookHelper.useBaseHook();

  return (
    <View style={{ flex: 1 }}>
      <DrawerContentScrollView
        {...props}
        contentContainerStyle={{ backgroundColor: "#8200d6" }}
      >
        <ImageBackground
          source={images.menuBg}
          style={{ padding: 20, alignItems: "center" }}
        >
          <Image
            source={images.appIcon}
            style={{
              height: 120,
              width: 120,
              marginBottom: 10,
              tintColor: "#fff",
            }}
          />
          {/* <Text
            style={{
              color: "#fff",
              fontSize: 30,
              marginBottom: 5,
            }}
          >
            IPS
          </Text> */}
          <Text
            style={{
              color: "#fff",
              fontSize: 14,
              marginBottom: 5,
              alignSelf: "flex-start",
            }}
          >
            Hệ thống định vị du lịch
          </Text>
          <Text
            style={{
              color: "#fff",
              fontSize: 14,
              marginBottom: 5,
              alignSelf: "flex-start",
            }}
          >
            Công nghệ Bluetooth năng lượng thấp
          </Text>
        </ImageBackground>
        <View style={{ flex: 1, backgroundColor: "#fff", paddingTop: 10 }}>
          <DrawerItemList {...props} />
        </View>
      </DrawerContentScrollView>
      <View style={{ padding: 20, borderTopWidth: 1, borderTopColor: "#ccc" }}>
        <TouchableOpacity
          onPress={() => {
            dispatch(AuthenticationActions.logout.request());
          }}
          style={{ paddingVertical: 15 }}
        >
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <Ionicons name="exit-outline" size={22} />
            <Text
              style={{
                fontSize: 15,
                marginLeft: 5,
              }}
            >
              Sign Out
            </Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default CustomDrawer;
