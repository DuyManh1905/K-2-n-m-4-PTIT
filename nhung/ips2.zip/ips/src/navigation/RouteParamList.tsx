import { Device } from "../model/Device";

export type RouteParamList = {
  DrawerRoute:
    | undefined
    | {
        screen?: 'Home' | 'Favorite' | 'Cart' | 'Profile';
        params?: any;
      };
  Login: undefined;
  Home: undefined;
  Splash: undefined;
  Map: undefined;
  MapUser: {device?: Device} | undefined;
  MapSearch: undefined;
};

export const ProtectedScreens: Array<keyof RouteParamList> = [];
