import "react-native-gesture-handler";

import * as React from "react";

import { createDrawerNavigator } from "@react-navigation/drawer";
import { NavigationContainer } from "@react-navigation/native";
import Ionicons from "react-native-vector-icons/Ionicons";
import { PointScreen } from "../screens/Point";
import { WaysScreen } from "../screens/Ways";
import { HomeRoute } from "./HomeRoute";
import CustomDrawer from "./components/CustomDrawer";
import { useAppSelector } from "../helpers/hookHelper";

const Drawer = createDrawerNavigator();

function DrawerRoute() {
  const authenticationReducer = useAppSelector(
    (state) => state.AuthenticationReducer
  );
  return (
    <NavigationContainer>
      <Drawer.Navigator
        drawerContent={(props) => <CustomDrawer {...props} />}
        screenOptions={{
          headerShown: false,
        }}
      >
        <Drawer.Screen
          name="HomeRoute"
          options={{
            drawerLabel: "Danh sách tầng",
            title: "Danh sách tầng",
            drawerIcon: ({ color }) => (
              <Ionicons name="map-outline" size={22} color={color} />
            ),
          }}
          component={HomeRoute}
        />

        {authenticationReducer.isAdmin && <Drawer.Screen
          name="Point"
          options={{
            drawerLabel: "Danh sách beacons",
            title: "Danh sách beacons",
            drawerIcon: ({ color }) => (
              <Ionicons name="bluetooth-outline" size={22} color={color} />
            ),
          }}
          component={PointScreen}
        />}
        {authenticationReducer.isAdmin && <Drawer.Screen
          name="Ways"
          options={{
            drawerLabel: "Danh sách đường đi",
            title: "Danh sách đường đi",
            drawerIcon: ({ color }) => (
              <Ionicons name="analytics-outline" size={22} color={color} />
            ),
          }}
          component={WaysScreen}
        />}
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

export default DrawerRoute;
