import { PayloadAction } from "@reduxjs/toolkit";
import {
  IBaseReducerState,
  createHandleReducer,
} from "../../helpers/reduxHelpers";
import { AuthenticationActions } from "../actions";

interface IAuthenticationState extends IBaseReducerState {
  accountNumber?: string;
  isAdmin?: boolean;
}

const initialState: IAuthenticationState = {
  isAdmin: false,
};

const logOut = (state: IAuthenticationState) => {  
  state.accountNumber = undefined;
};

const setIsAdmin = (state: IAuthenticationState, action: PayloadAction<boolean>) => {
  state.isAdmin = action.payload;
};
const AuthenticationReducer = createHandleReducer(initialState, (builder) => {
  builder
    .addCase(AuthenticationActions.logout.request, logOut)
    .addCase(
      AuthenticationActions.setAccountNumber.request,
      (state: IAuthenticationState, action: PayloadAction<string>) => {
        state.accountNumber = action.payload;
      }
    )
    .addCase(AuthenticationActions.setIsAdmin.request, setIsAdmin);
});

export default AuthenticationReducer;
