import { createReducer, PayloadAction } from "@reduxjs/toolkit";
import {
  IBaseReducerState,
  createHandleReducer,
} from "../../helpers/reduxHelpers";
import { UserActions } from "../actions";
import { Device } from "../../model/Device";
import { Way } from "../../model/Way";
interface IUserState extends IBaseReducerState {
  listDevice: Device[];
  listWay: Way[];
}

const initialState: IUserState = {
  listDevice: [
    {
      id: 1,
      x: 240,
      y: 670,
      mac: "80:EA:CA:00:00:01",
      rssi: -10,
      title: "Hồ Văn",
      description: "Xây dựng năm 1070, thời Lý.\nHồ nước lớn nhất Văn Miếu",
    },

    {
      id: 2,
      x: 235,
      y: 614,
      mac: "80:EA:CA:00:00:03",
      rssi: -30,
      title: "Tứ trụ",
      description: "4 cột đá chữ nhật, cao 3m, mỗi cột 1 tấm bia",
    },
    {
      id: 3,
      x: 237,
      y: 586,
      mac: "80:EA:CA:00:00:05",
      rssi: -50,
      title: "Cổng Văn Miếu",
      description: "Cổng chính của Văn Miếu",
    },
    {
      id: 4,
      x: 235,
      y: 454,
      mac: "80:EA:CA:00:00:05",
      rssi: -50,
      title: "Cổng Đại Trung",
      description: "Cổng chính của Văn Miếu",
    },
    {
      id: 5,
      x: 105,
      y: 450,
      mac: "80:EA:CA:00:00:04",
      rssi: -40,
      title: "Vườn Giám",
      description: "Nơi trồng cây cỏ, nuôi cá, chim",
    },
  ],
  listWay: [
    {
      start: 1,
      end: 2,
    },

    {
      start: 2,
      end: 3,
    },
    {
      start: 3,
      end: 4,
    },
    {
      start: 4,
      end: 5,
    },
  ],
};

const setListDevice = (state: IUserState, action: PayloadAction<Device[]>) => {
  state.listDevice = action.payload;
};
const setListWay = (state: IUserState, action: PayloadAction<Way[]>) => {
  state.listWay = action.payload;
};

const UserReducer = createHandleReducer(initialState, (builder) => {
  builder
    .addCase(UserActions.setListDevice.request, setListDevice)
    .addCase(UserActions.setWays.request, setListWay);
});

export default UserReducer;
