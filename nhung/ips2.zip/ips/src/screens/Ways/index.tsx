import React from "react";
import { FlatList, TouchableOpacity, View } from "react-native";
import { HookHelper } from "../../helpers";
import useStyles from "./styles";
import AppText from "../../components/atoms/AppText";
import { Icon, Switch } from "react-native-elements";
import { useAppSelector } from "../../helpers/hookHelper";
import { DeleteWayDialog } from "../../components/modules/DeleteWayDialog";
import { AddWayDialog } from "../../components/modules/AddWayDialog";
import AppHeader from "../../components/atoms/Header";

const WaysItem = ({ item, index }: any) => {
  const { theme, dispatch } = HookHelper.useBaseHook();
  const styles = useStyles(theme);
  const [isEnabled, setIsEnabled] = React.useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = React.useState(false);

  return (
    <View style={styles.pointItem}>
      <View style={styles.rowContainer}>
        <View style={styles.indexContainer}>
          <AppText white>{item.start}</AppText>
        </View>
        <Icon
          name="swap-horizontal"
          color={"black"}
          size={36}
          style={styles.icon}
        />
        <View style={styles.indexContainer}>
          <AppText white>{item.end}</AppText>
        </View>
      </View>

      <TouchableOpacity onPress={() => setShowDeleteDialog(true)}>
        <Icon name="delete" color={"red"} />
      </TouchableOpacity>
      <DeleteWayDialog
        isVisible={showDeleteDialog}
        setIsVisible={setShowDeleteDialog}
        way={item}
      />
    </View>
  );
};

export const WaysScreen = () => {
  const { theme, dispatch } = HookHelper.useBaseHook();
  const styles = useStyles(theme);
  const userReducer = useAppSelector((state) => state.UserReducer);
  const [showAddDialog, setShowAddDialog] = React.useState(false);

  return (
    <View style={styles.container}>
      <AppHeader title="Danh sách beacons" />
      <View style={styles.content}>
        <FlatList
          data={userReducer?.listWay}
          renderItem={({ item, index }) => (
            <WaysItem item={item} index={index} />
          )}
          keyExtractor={(item, index) => index.toString()}
        />
        <TouchableOpacity
          style={styles.adddBtn}
          onPress={() => setShowAddDialog(true)}
        >
          <Icon name="plus" color={"white"} size={30} />
        </TouchableOpacity>
      </View>

      <AddWayDialog isVisible={showAddDialog} setIsVisible={setShowAddDialog} />
    </View>
  );
};
