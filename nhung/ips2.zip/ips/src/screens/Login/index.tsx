import React, { useState } from "react";
import { View } from "react-native";

import AppInput from "../../components/atoms/AppInput";
import AppText from "../../components/atoms/AppText";
import AppButton from "../../components/atoms/Button";
import { ErrorModal } from "../../components/atoms/ErrorModal";
import { HookHelper } from "../../helpers";
import { useGetNavigation } from "../../helpers/hookHelper";
import { AuthenticationActions, UserActions } from "../../stores/actions";
import useStyles from "./styles";

export const LoginScreen = () => {
  const { theme, dispatch } = HookHelper.useBaseHook();
  const { navigation } = useGetNavigation();

  const [phoneString, setPhoneString] = useState("");
  const [passwordString, setPasswordString] = useState("");
  const [savePassword, setSavePassword] = useState(false);
  const styles = useStyles(theme);
  const [showError, setShowError] = useState(false);
  const [error, setError] = useState<{ title: string; description?: string }>();
  const onNext = async () => {
    if (phoneString == "" || passwordString == "") {
      setError({
        title: "Lỗi",
        description: "Vui lòng nhập đầy đủ thông tin",
      });
      setShowError(true);
      return;
    }
    if (phoneString == "admin" && passwordString == "admin") {
      dispatch(AuthenticationActions.setIsAdmin.request(true));
    } else {
      dispatch(AuthenticationActions.setIsAdmin.request(false));
    }
    dispatch(AuthenticationActions.setAccountNumber.request(phoneString));
  };
  const tryAgain = () => {
    setShowError(false);
    setError(undefined);
  };

  return (
    <View style={styles.container}>
      <View>
        <AppText style={styles.title}>Xin chào! 👋</AppText>
        <View style={styles.inputContainer}>
          <AppText style={styles.inputLabel}>Tên đăng nhập</AppText>
          <AppInput
            label={"Hãy nhập tên đăng nhập"}
            value={phoneString}
            onChangeText={(text) => setPhoneString(text)}
            containerStyles={styles.inputStyle}
          />
        </View>
        <View style={styles.inputContainer}>
          <AppText style={styles.inputLabel}>Mật khẩu</AppText>
          <AppInput
            label={"Hãy nhập mật khẩu"}
            value={passwordString}
            maxLength={100}
            isPassword
            keyboardType="default"
            onChangeText={(text) => setPasswordString(text)}
            containerStyles={styles.inputStyle}
          />
        </View>
      </View>

      <AppButton
        title={"Đăng nhập"}
        onPress={() => onNext()}
        customBtnStyle={styles.buttonStyle}
      />

      <ErrorModal
        confirmTitle={"Try again"}
        onConfirm={() => tryAgain()}
        isVisible={showError}
        title={error?.title || ""}
        description={error?.description}
      />
    </View>
  );
};
