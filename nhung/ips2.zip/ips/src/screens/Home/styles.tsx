import { makeStyles } from "react-native-elements";
import { Mixin } from "../../helpers";

export default makeStyles((theme) => ({
  container: {
    backgroundColor: theme.colors?.backgroundItem,
    height: "100%",
  },

  content: {
    paddingHorizontal: Mixin.moderateSize(16),
    paddingTop: Mixin.moderateSize(16),
  },

  button: {
    backgroundColor: theme.colors?.primary,
    height: Mixin.moderateSize(40),
    borderRadius: Mixin.moderateSize(5),
    justifyContent: "center",
    alignItems: "center",
    marginVertical: Mixin.moderateSize(8),
  },
}));
