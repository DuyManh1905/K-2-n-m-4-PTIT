import { makeStyles } from "react-native-elements";
import { Mixin } from "../../helpers";

export default makeStyles((theme) => ({
  container: {
    paddingHorizontal: Mixin.moderateSize(60),
    height: "100%",
    alignItems: "center",
    paddingTop: Mixin.moderateSize(50),
    backgroundColor: 'white',
  },
  image: {
    width: Mixin.moderateSize(200),
    height: Mixin.moderateSize(200),
    alignSelf: "center",
  },
  title: {
    fontSize: Mixin.moderateSize(40),
    fontWeight: "bold",
  },
  description: {
    textAlign: "center",
    fontSize: Mixin.moderateSize(16),
    marginTop: Mixin.moderateSize(20),
    marginBottom: Mixin.moderateSize(30),

  },
  rowContainer: {
    flexDirection: "row",
    marginTop: Mixin.moderateSize(80),
  },
}));
