import { makeStyles } from "react-native-elements";
import { Mixin } from "../../helpers";

export default makeStyles((theme) => ({
  container: {
    height: "100%",
    alignItems: "center",
    paddingTop: Mixin.moderateSize(30),
  },
  content: {
    flex: 1,
    width: "100%",
    height: "100%",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%",
    backgroundColor: "white",
    paddingVertical: Mixin.moderateSize(10),
    paddingHorizontal: Mixin.moderateSize(16),
    elevation: 5,
  },
  inputStyle: {
    flex: 1,
    borderRadius: Mixin.moderateSize(5),
    paddingHorizontal: Mixin.moderateSize(16),
    height: Mixin.moderateSize(40),
    marginHorizontal: Mixin.moderateSize(10),
    fontSize: Mixin.moderateSize(16),
  },
  searchItem: {
    marginHorizontal: Mixin.moderateSize(16),
    marginVertical: Mixin.moderateSize(10),
  },
  listItemText: {
    fontSize: Mixin.moderateSize(14),
    color: theme.colors?.primary
  }
}));
