import React, { useEffect, useState } from "react";
import {
  FlatList,
  SafeAreaView,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { Icon } from "react-native-elements";
import { HookHelper } from "../../helpers";
import { useAppSelector, useGetNavigation } from "../../helpers/hookHelper";
import useStyles from "./styles";
import AppText from "../../components/atoms/AppText";

export const MapSearchScreen = () => {
  const { theme, dispatch } = HookHelper.useBaseHook();
  const { navigation } = useGetNavigation();
  const styles = useStyles(theme);
  const userReducer = useAppSelector((state) => state.UserReducer);
  const [searchText, setSearchText] = useState("");
  const [listSearch, setListSearch] = useState(userReducer.listDevice);

  useEffect(() => {
    setListSearch(
      userReducer.listDevice.filter((item) =>
        item.title.toLowerCase().includes(searchText.toLowerCase())
      )
    );
  }, [searchText]);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Icon name="arrow-left" size={26} color={"black"} />
        </TouchableOpacity>
        <TextInput
          placeholder="Search"
          value={searchText}
          onChangeText={(text) => setSearchText(text)}
          style={styles.inputStyle}
        />
        <TouchableOpacity onPress={() => setSearchText("")}>
          <Icon name="close" size={26} color={"black"} />
        </TouchableOpacity>
      </View>
      <View style={styles.content}>
        <FlatList
          data={listSearch}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.searchItem}
              onPress={() => {
                navigation.goBack();
                navigation.replace("MapUser", { device: item });
              }}
            >
              <AppText style={styles.listItemText}>{item.title}</AppText>
            </TouchableOpacity>
          )}
        />
      </View>
    </SafeAreaView>
  );
};
