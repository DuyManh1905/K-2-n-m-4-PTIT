package ptit.android.kt2_template.model;

import java.io.Serializable;

public class MyModel implements Serializable {

}
