package ptit.android.demo;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Ex3RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    void init(){
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exercise03_2);
        init();
    }

    @Override
    public void onClick(View view) {
    }
}
