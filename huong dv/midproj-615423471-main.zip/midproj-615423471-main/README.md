Đề tài : CASE STUDY NHẬP ĐIỂM

Nhóm 9

Lương Nhật Tuấn : B20DCCN615

Trần Minh Nghĩa : B20DCCN471

Lê Duy Mạnh : B20DCCN423


Case study : Import điểm từ file



I.	Phân tích

1.1	 Thực hiện mô hình hóa dịch vụ REST cho quy trình “Import điểm cho sinh viên từ file”. Quy trình này bao gồm:

• Đánh giá bảng điểm do giảng viên nhập cho môn học của học kì mà giảng viên đang dạy

• Kiểm tra file điểm nhập vào có hợp lệ hay không

• Kiểm tra xem môn học có do giảng viên giảng dạy không  	Phê duyệt nhập điểm của giảng viên

1.2	 Phân tách quy trình thành các hành động chi tiết:
 Quy trình nhập điểm được chia thành các hành động chi tiết: 
 
 •	Bắt đầu nhập điểm
 
 •	Xác định thời gian nhập điểm
 
 •	Nếu ngoài thời gian thì không cho phép nhập
 
 •	Nhập vào file cần lấy điểm
 
 •	Lấy ra kỳ học có trong file
 
 •	Xác thực các kỳ học mà giảng viên đang dạy
 
 •	Lấy ra môn học trong file
 
 •	Xác minh môn học phải do giáo viên giảng dạy
 
 •	Nếu không phải bắt đầu từ chối và hiển thị thông báo
 
 •	Gửi thông báo từ chối
 
 •	Gửi thông báo chấp nhận
 
 •	Lấy ra lớp học phần trong file
 
 •	Xác minh lớp học phần do giáo viên giảng dạy
 
 •	Nếu không phải bắt đầu từ chối
 
 •	Gửi thông báo từ chối
 
 •	Gửi thông báo chấp nhận
 
 •	Lấy ra danh sách sinh viên
 
 •	Export điểm tương ứng 
 
 • Xác minh điểm đúng định dạng
 
 • Nếu không phải bắt đầu từ chối
 
 • Gửi thông báo từ chối
 
 •	Gửi thông báo chấp nhận
 
 •	Gửi thông báo chấp nhận
 
 •	Thêm bản ghi điểm vào cơ sở dữ liệu

1.3	Lọc ra các hành động không phù hợp :
 1.	Bắt đầu nhập điểm
 2.	Xác định thời gian nhập điểm
 3.	Nếu ngoài thời gian thì không cho phép nhập
 4.	Nhập vào file cần lấy điểm
 5.	Lấy ra kỳ học có trong file
 6.	Xác thực các kỳ học mà giảng viên đang dạy
 7.	Lấy ra môn học trong file
 8.	Xác minh môn học phải do giáo viên giảng dạy
 9.	Nếu không phải bắt đầu từ chối và hiển thị thông báo
 10.	Gửi thông báo từ chối
 11.	Gửi thông báo chấp nhận
 12.	Lấy ra lớp học phần trong file
 13.	Xác minh lớp học phần do giáo viên giảng dạy
 14.	Nếu không phải bắt đầu từ chối
 15.	Gửi thông báo từ chối
 16.	Gửi thông báo chấp nhận
 17.	Lấy ra danh sách sinh viên
 18.	Export điểm tương ứng
 19.	Xác minh điểm đúng định dạng
 20.	Nếu không phải bắt đầu từ chối
 21.	Gửi thông báo từ chối
 22.	Gửi thông báo chấp nhận
 23.	Gửi thông báo chấp nhận
 24.	Thêm bản ghi điểm vào cơ sở dữ liệu

1.4	Xác định ứng viên dịch vụ thực thể:
  • Kết quả xác định các hành động bất khả tri:  
   Lấy danh sách kì học
   Gửi thông báo từ chối
   Gửi thông báo chấp nhận   
   Lấy danh sách môn học
   Lấy chi tiết lớp học phần
   Lấy danh sách sinh viên  
   Giảng viên click lưu bảng điểm
  
    Thêm bản ghi điểm vào cơ sở dữ liệu
    Các hành động bất khả tri được phân loại là các ứng viên năng lực dịch vụ sơ bộ và được nhóm lại tương ứng vào các ứng viên năng lực dịch vụ:
    o	Ứng viên dịch vụ kỳ học (Term)
    	GetListTerm
    	CheckListTerm
    o	Ứng viên dịch vụ Môn học(Subject)
    	GetListSubject
    	CheckListSubject
    o	Ứng viên dịch vụ Lớp học phần(SectionClass)
    	GetListSectionClass
    o	Ứng viên dịch vụ Sinh viên (Student)
    	GetListStudent
    	CheckListStudent
    	saveScore
    	checkScore

1.5.	 Xác định logic quy trình cụ thể
 	Các hành động sau đây được coi là không bất khả tri vì chúng dành riêng cho quy trình nghiệp vụ “Nhập điểm cho sinh viênˮ
  
   Bắt đầu nhập điểm
   
   Xác minh môn học phải do giáo viên giảng dạy
   
   Nếu không phải, bắt đầu từ chối
   
   Xác minh lớp học phần phải do giáo viên giảng dạy
   
   Nếu không phải, bắt đầu từ chối
   
   Xác minh sinh viên thuộc lớp học phần phải do giáo viên giảng dạy
   
   Nếu không phải, bắt đầu từ chối
   
   Giảng viên export file điểm
   
   Xác minh xem file có phải lỗi định dạng
   
   Nếu phải, bắt đầu từ chối
   
   Giảng viên click lưu bảng điểm
   
   Xác minh điểm giảng viên nhập vào có đáp ứng yêu cầu
   
   Nếu bảng điểm giảng viên không đủ điều kiện , Bắt đầu từ chối 
   
   Thêm bản ghi điểm vào cơ sở dữ liệu
 	 
   Trong số các hành động này , hành động đầu tiên được coi là ứng cử viên năng lực dịch vụ là tạo nên cơ sở của một ứng viên dịch vụ tác vụ được gọi là “Nhập điểm sinh viênˮ . Các hành động còn lại
được xác định là logic nội bộ trong dịch vụ tác vụ này :   EnterScoresForStudents:
 	
  Start
 	
  Ứng cử viên EnterScoresForStudents với một năng lực dịch vụ duy nhất Start
  
1.6.	Xác định tài nguyên:

Sau khi xem xét các yêu cầu xử lý của khả năng dịch vụ đã được xác định , các tài nguyên tiềm năng sau đây được xem xét :

_  /EnterScoresForStudents/

_ /SectionClass/

_ /Student/

_ /Subject/

_ /Term/

_ /POint/

Thiết lập một số ánh xạ sơ bộ giữa các tài nguyên và thực thể kinh doanh được xác định


Entity	Resource

SectionClass	_ /SectionClass/

Student	_ /Student/

Subject	_ /Subject/

Term	_ /Term/

Point_/Point/

1.7. Liên kết năng lực dịch vụ với tài nguyên và các phương thức :
 	
  Ứng viên dịch vụ Kì học(Term) :
   
   GetListTerm (GET +/ Term/)

   CheckTerm ( POST + /Term/ )
 	
  Ứng viên dịch vụ Môn học(Subject) : 
   
   GetListSubject(GET +/ Subject/)
 
   CheckSubject ( POST + /Subject/ )
 	
  Ứng viên dịch vụ Lớp học phần (SectionClass):  
   
   GetList(GET + /SectionClass/)
  
   CheckCapacity(POST +/SectionClass/)
  
   CheckDuplicateSchedule(POST + /SectionClass/)  	
  Ứng viên dịch vụ Sinh viên (Student):
  
   CheckSubjectOfSemester (POST + /Student/)  
   
   saveScore(POST + /Student/SaveScore/)
   
   checkScore(POST + /Student/CheckScore/)
   
  Ứng viên point:
   
   verify Point(POST +/Point/savePoint/)
 	
  (Tác vụ)EnterScoresForStudents:
  
   Start (POST + /EnterScoresForStudents/)

1.8	Xác định ứng viên tổ hợp dịch vụ
![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/59486568-826b-4ffa-8f8d-7badd913e2f6)


1.9	Phân tích các yêu cầu xử lý
 
 	Các chức năng mang tính chất tiện ích :
   Gửi thông báo từ chối
   Gửi thông báo cho phép
   Gửi thông báo thành công
 	Các hành động có yêu cầu xử lý quan trọng và chuyên biệt :
   Kiểm tra xem sinh viên thuộc lớp học phần phải do giáo viên giảng dạy
   Kiểm tra môn học phải do giáo viên giảng dạy
   Kiểm tra điểm giảng viên nhập vào có đáp ứng yêu cầu


   
1.10	Xác định các ứng viên dịch vụ tiện ích (Và liên kết các tài nguyên phương thức ):
![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/55be557b-a0c1-43b3-9c64-1ced169d37a5)


 
 	
  
  
  Ứng viên dịch vụ thông báo
1.11	Xác định các ứng viên microservice (liên kết tài nguyên và phương thức )

•	
Để cô lập việc xử lý hành động “Kiểm tra xem danh sách các kỳ học có đủ yêu cầu nằm trong thời gian hợp lệ hay không ˮ ⇒ đề xuất một ứng viên
microservice có tên “Verify Termˮ , và hành động “ Kiểm tra lớp học phần mới được chọn có lịch học trùng với lịch học của lớp học phần đã chọn ˮ ⇒ đề xuất một ứng viên có tên “Verify Section Classˮ và hành động “Kiểm tra xem môn học có nằm trong học kỳ hợp lệ hay không có tên “Verify Subjectˮ.


![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/b3cfd91b-fed6-4f49-81e7-986e6bde19e9)


1.12	Cấu trúc phân cấp các ứng viên dịch vụ sau khi kết hợp và mở rộng :
 
![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/e1932fce-a413-475e-9483-11c9192d96e4)



II.	Phân tích
1.	 Biểu đồ tuần tự
 ![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/3fe0caa5-8120-443e-ad56-69ab90900d50)

III. Các công nghệ kĩ thuật
1. Api gateway
   - sử dụng Kong để triển khai 2 service:
     ![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/e515ebed-74ee-4608-890b-a31e909967cc)
     + với service profile sử dụng các giao thức http với 2 routing:
       ![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/2864dac1-8605-4775-9df6-18dc57143552)
     + với service websocket sử dụng :
       ![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/ebbb02cc-c4c8-45ae-be9f-0e24e485f53b)

2. Caching
   - sử dụng database caching redis để quản lý các kết nối websocket:
     ![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/7407d44b-6245-4436-bd81-8cbbb2028393)

3. Message Broker
   - Kết hợp với Django-Channels để quản lý mô hình pub/sub:
     ![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/0fa35a79-39d9-4068-a43c-4c24f3bd1595)
     ![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/6dc158e0-ea27-4d62-8ca1-a4c597c2fd44)

4. Container:
   - sử dụng docker để quản lý và triển khai kong gateway:
     ![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/81ca2fc8-8a0c-4e6f-bb98-200a3a8dbd9c)
   - Sử dụng docker để quản lý và triển khai redis:
     ![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/15fa69f2-af37-4a86-8877-9fd0935a0da9)
5. Sercurity
   - sử dụng jwt để xác thực với cổng api gateway kong:
     ![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/e3af40cc-3db6-4a97-a4f5-64d92fe4bf52)
   - Kết hợp jwt để xác thực ở service:
     ![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/252bf1ce-576b-459d-a8bc-81073bceadc8)


9. swagger
    - sử dụng swagger để quản lý cacs Restfull Api :
      ![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/28bff8c1-0976-47b5-aedd-612d0d192975)

11. Websocket
    - sử dụng django- channels để thực hiện giao thức websocket hỗ trỡ cho quá trình hiển thị processbar
      ![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/200584c0-9122-4efc-961a-8703d9ca192c)
      ![image](https://github.com/jnp2018/midproj-615423471/assets/97106096/f23a8b2a-fbb4-4535-ad63-c63ae65c2eb7)
 
 
