from django.urls import path
from .views import SaveDataTable,SectionClassAll

urlpatterns = [
    path('saveDataTable', SaveDataTable.as_view(), name='save_score'),
    path('SectionClass', SectionClassAll.as_view(), ),
    
]
