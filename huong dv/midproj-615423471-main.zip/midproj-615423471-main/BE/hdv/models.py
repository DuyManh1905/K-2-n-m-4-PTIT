from django.db import models
# Create your models here.
class Teacher(models.Model):
    fullName = models.CharField(max_length=255)
    mgv = models.CharField(max_length=255)
    def __str__(self):
        return self.fullName

class Student(models.Model):
    fullName = models.CharField(max_length=255)
    msv = models.CharField(max_length=255, null=True, blank=True)
    def __str__(self):
        return self.fullName
      
class Term(models.Model):
    name = models.CharField(max_length=255)
    def __str__(self):
        return self.name

class Subject(models.Model):
    name = models.CharField(max_length=255)

class SectionClass(models.Model):
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    term = models.ForeignKey(Term, on_delete=models.CASCADE)
    name = models.CharField(max_length=225,null=True,default="toasn 1")

class StudentSectionClass(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    sectionClass = models.ForeignKey(SectionClass, on_delete=models.CASCADE)

class Point(models.Model):
    diemChuyenCan = models.FloatField(null=True, blank=True)
    diemTrungBinhKiemTra = models.FloatField(null=True, blank=True)
    diemThiNghiemThucHanh = models.FloatField(null=True, blank=True)
    diemBaiTapLon = models.FloatField(null=True, blank=True)
    diemThi = models.FloatField(null=True, blank=True)
    studentSectionClass = models.ForeignKey(StudentSectionClass, on_delete=models.CASCADE)