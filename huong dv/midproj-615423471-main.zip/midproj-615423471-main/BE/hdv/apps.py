from django.apps import AppConfig


class HdvConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hdv'
