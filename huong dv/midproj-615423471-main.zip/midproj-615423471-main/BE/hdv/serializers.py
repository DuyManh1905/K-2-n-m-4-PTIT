from rest_framework import serializers
from .models import Term, Teacher, Student, Subject,SectionClass



class SectionClassSerializer(serializers.ModelSerializer):
    class Meta:
        model = SectionClass
        fields = "__all__"
