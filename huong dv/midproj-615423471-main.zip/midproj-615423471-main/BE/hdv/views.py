from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import SectionClassSerializer
from channels.layers import get_channel_layer
import time
from asgiref.sync import async_to_sync
from .models import SectionClass,Student,Teacher,Point,StudentSectionClass,Term
class SaveDataTable(APIView):
    def post(self, request):
        studentList=request.data["students"]
        k=1
        for student in studentList:
            time.sleep(0.5)

            k=k+1
            channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                "chat_1", {"type": "chat.message", "message": str(k/len(studentList))}
            )
            # if student["msv"]!="" and student["msv"]!="B20DCCN471":
            #     stu=Student(fullName=student["ho"]+" "+student["ten"],msv=student["msv"])
            #     stu.save()
            #     StudentSectionClass(student=stu,sectionClass=SectionClass.objects.get(pk=1)).save()
            if student["msv"]!="":
                
                students = Student.objects.filter(msv=student["msv"])
                if(len(students)==0):continue
                studentObj= students[0]
                sectionClass=SectionClass.objects.all()[0]
                studentSectionClass= StudentSectionClass.objects.filter(student=studentObj,sectionClass=sectionClass)
                if(student["msv"]=="B20DCCN471"):print(studentSectionClass)
                if(len(studentSectionClass)==0):continue
                point=Point.objects.filter(studentSectionClass=studentSectionClass[0])
                print(point)
                if(len(point)==0):
                    
                    pointNew= Point( diemChuyenCan =student["diemChuyenCan"] if student["diemChuyenCan"]!="" else None,
                                diemTrungBinhKiemTra =student["diemTrungBinhKiemTra"] if student["diemTrungBinhKiemTra"]!="" else None,
                                diemThiNghiemThucHanh = student["diemThiNghiemThucHanh"] if student["diemThiNghiemThucHanh"]!="" else None,
                                diemBaiTapLon = student["diemBaiTapLon"] if student["diemBaiTapLon"]!="" else None,
                                diemThi = student["diemThi"] if student["diemThi"]!=""  else None,
                                studentSectionClass=studentSectionClass[0] ).save()
                
        return Response("",status=200)
        # if serializer.is_valid():
        #     serializer.save()
        #     return Response({"message": "Data saved successfully"}, status=status.HTTP_201_CREATED)
        # return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class SectionClassAll(APIView):
    def get(request,self):
        sectionClass=SectionClass.objects.filter(term__pk=1,teacher=1)
        sectionClassSerializer = SectionClassSerializer(sectionClass,many=True)
        return Response(sectionClassSerializer.data,200)
