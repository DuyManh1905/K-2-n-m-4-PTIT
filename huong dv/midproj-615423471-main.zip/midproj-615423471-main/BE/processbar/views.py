from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
# Create your views here.
class ok(APIView):
    def get(self,request):
        print(request.headers.get('Authorization'))
        return Response({"s":"s"},200)