from django.urls import path
from .views import ok
urlpatterns = [
    path('hh',ok.as_view())
]