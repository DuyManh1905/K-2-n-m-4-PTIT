import { get, post } from "../utils/request";

export const sendDataTable = async (value,option) => {
  try {
    const res = await post(value,option);
    const data = await res.json();
    return data;
  } catch (err) {
    console.log(err);
    return [];
  }
};

export const getAllSectionClass = async (option) => {
  try {
    const res = await get(option);
    const data = await res.json();
    return data;
  } catch (err) {
    console.log(err);
    return [];
  }
};
