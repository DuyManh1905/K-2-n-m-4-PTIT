/* eslint-disable no-unused-vars */
import { Layout, Flex, Button, Collapse, Image, Table } from "antd";
import { Outlet } from "react-router-dom";
import { HomeOutlined, UserOutlined } from "@ant-design/icons";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./layout.css";
import '../assets/css/root.css'
import './style.scss'
import SiderContainer from "../components/SiderContainer";
import { w3cwebsocket } from 'websocket';
const { Footer, Sider, Content } = Layout;

function LayoutDefault() {
  const [collapsed, setCollapsed] = useState(false);
  const [pageTitle, setPageTitle] = useState("");
  const [statusProcess,setStatusProcess] =useState(0);
  const [tienTrinh, setTienTrinh] = useState(0);



  useEffect(() => {
    const ws = new w3cwebsocket('ws://127.0.0.1:8080/ws/chat/1/');

    ws.onopen = () => {
      console.log('WebSocket connected');
      ws.send(JSON.stringify({ type: 'join', message: '0' }));
    };
  
    ws.onmessage = (message) => {
      console.log('Received message:',JSON.parse( message.data)["message"]);
      if(JSON.parse( message.data)["message"]!=NaN)setTienTrinh(JSON.parse( message.data)["message"]);
    };
  
    ws.onclose = () => {
      console.log('WebSocket connection closed');
    };
  }, []);
  return (
    
    <>
    <div style={{ marginBottom: -4,position:'fixed',top:0,left:0,right:0,zIndex:100}}>
      <progress style={{width: 1390}} className="progress" value={tienTrinh} max="1"></progress>
    </div>
    <Layout className="layout-default">
      <header className="container__header">
        <div className="header__left">
          <button className="header-home">
            <HomeOutlined />
            <p style={{marginLeft: 10}}>Trang chủ</p>
          </button>
          <button className="header-infor">
            <UserOutlined />
            <p style={{marginLeft: 10}}>Thông tin</p>
          </button>
        </div>
      </header>
    
      <Layout>
        <Content className="content">
          <Outlet />
        </Content>
        <Sider width={"280px"} theme="light" collapsed={collapsed}>
          <SiderContainer />
        </Sider>
      </Layout>
    </Layout>
    </>
  );
}
export default LayoutDefault;
