// import { Dropdown, Button,Divider,Badge,Space } from "antd";
// import { BellOutlined } from "@ant-design/icons";
// import './notify.scss'
// const items = [
//   {
//     label: (
//       <div className="notify__header">
//         <div className="notify__header-left">
//           <div className="notify__bell">
//             <BellOutlined />
//           </div>
//           <div className="notify__title">Notification</div>
//         </div>
//         <div className="notify__header-right">
//           <Button type="text" style={{color: 'blue'}}>Views All</Button>
//         </div>
//       </div>
//     ),
//     key: "0",
    
//   },
//   {
//     type: 'divider',
//   },
//   {
//     label: (
//       <div className="notify__content">
//         <div className="notify__box">
//           <div className="notify-icon">
//             <BellOutlined />
//           </div>
//           <div className="notify-detail">
//             <h4>You recive a message</h4>
//             <p className="notify-time">8 min ago</p>
//           </div>
//         </div>
//       </div>
//     ),
//     key: "1",
//   },
//   {
//     type: 'divider'
//   },
//   {
//     label: (
//       <div className="notify__content">
//         <div className="notify__box">
//           <div className="notify-icon">
//             <BellOutlined />
//           </div>
//           <div className="notify-detail">
//             <h4>You recive a message</h4>
//             <p className="notify-time">8 min ago</p>
//           </div>
//         </div>
//       </div>
//     ),
//     key: "2",
//   },
//   {
//     type: 'divider'
//   },
//   {
//     label: (
//       <div className="notify__content">
//         <div className="notify__box">
//           <div className="notify-icon">
//             <BellOutlined />
//           </div>
//           <div className="notify-detail">
//             <h4>You recive a message</h4>
//             <p className="notify-time">8 min ago</p>
//           </div>
//         </div>
//       </div>
//     ),
//     key: "3",
//   },
//   {
//     type: 'divider'
//   },
//   {
//     label: (
//       <div className="notify__content">
//         <div className="notify__box">
//           <div className="notify-icon">
//             <BellOutlined />
//           </div>
//           <div className="notify-detail">
//             <h4>You recive a message</h4>
//             <p className="notify-time">8 min ago</p>
//           </div>
//         </div>
//       </div>
//     ),
//     key: "4",
//   },
//   {
//     type: 'divider'
//   },
//   {
//     label: (
//       <div className="notify__content">
//         <div className="notify__box">
//           <div className="notify-icon">
//             <BellOutlined />
//           </div>
//           <div className="notify-detail">
//             <h4>You recive a message</h4>
//             <p className="notify-time">8 min ago</p>
//           </div>
//         </div>
//       </div>
//     ),
//     key: "5",
//   },
//   {
//     type: 'divider'
//   },
//   {
//     label: (
//       <div className="notify__content">
//         <div className="notify__box">
//           <div className="notify-icon">
//             <BellOutlined />
//           </div>
//           <div className="notify-detail">
//             <h4>You recive a message</h4>
//             <p className="notify-time">8 min ago</p>
//           </div>
//         </div>
//       </div>
//     ),
//     key: "6",
//   }
// ];
// function DropDownNotify() {
//   return (
//     <>
//       <Dropdown
//         overlayClassName="notify"
//         menu={{
//           items,
//         }}
//         trigger={["click"]}
//       >
//         <Badge style={{boxShadow:"none"}} count={99}>
//           <Button style={{background: "#fff", boxShadow: "none"}} icon={<BellOutlined />}></Button>
//         </Badge>
//       </Dropdown>
//     </>
//   );
// }

// export default DropDownNotify;
