import AllRoute from './components/AllRoute';
function App() {
  return (
    <>
      <AllRoute />
    </>
  );
}

export default App;
