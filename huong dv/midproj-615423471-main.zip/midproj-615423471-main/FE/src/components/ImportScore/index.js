import React, { useEffect, useRef, useState } from "react";
import {
  EditOutlined,
  PrinterOutlined,
  PlusOutlined,
  ImportOutlined,
} from "@ant-design/icons";
import "./importScore.css";
import "../../assets/css/root.css";
import ImportScoreSearch from "./importScoreSearch";
import readXlsxFile from "read-excel-file";
import { sendDataTable } from "../../service/hdvService";
function ImportScore() {
  const [dataTable, setDataTable] = useState([]);
  const [inputData, setInputData] = useState([]);
  const [term, setTerm] = useState("");
  const [subject, setSubject] = useState("");
  const fileInputRef = useRef(null);
  useEffect(() => {
    const createArray = () => {
      const newArray = [];
      for (let i = 0; i < 40; i++) {
        newArray.push({
          msv: "",
          hoTen: "",
          lop: "",
          diemChuyenCan: "",
          diemTrungBinhKiemTra: "",
          diemThiNghiemThucHanh: "",
          diemBaiTapLon: "",
          diemThi: "",
        });
      }
      return newArray;
    };
    setDataTable(createArray());
  }, []);

  const handleInputChange = (index, event) => {
    const { name, value } = event.target;
    const newData = [...dataTable];
    newData[index][name] = value;
    setDataTable(newData);

    // Update input data state
    const newInputData = [...inputData];
    newInputData[index] = { ...newInputData[index], [name]: value };
    setInputData(newInputData);
  };

  const handleSaveScores = () => {
    let students = dataTable.slice(1)
    students = students.map((item) => {
      Object.keys(item).forEach(key => {
        if (item[key] === null) {
          item[key] = "";
        }
      });
      return item;
    });

    console.log(students)
    const teacher = {
      fullName: "Trần Văn Ninh",
      mgv: "B20DCGV666"
    }
    console.log(term)
    console.log(subject)
    const fetch = () => {
      const res = sendDataTable({
        teacher: teacher,
        term: term,
        subject: subject,
        students: students
      }, "api/hdv/saveDataTable")
    }
    fetch()
  };

  const handleAddRow = () => {
    const newDataTable = [...dataTable];
    newDataTable.push({
      msv: "",
      hoTen: "",
      lop: "",
      diemChuyenCan: "",
      diemTrungBinhKiemTra: "",
      diemThiNghiemThucHanh: "",
      diemBaiTapLon: "",
      diemThi: "",
    });
    setDataTable(newDataTable);

    // Add an empty object to inputData
    setInputData([...inputData, {}]);
  };

  const handleButtonClick = () => {
    fileInputRef.current.click();
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      readXlsxFile(file)
        .then((rows) => {
          console.log(rows);
          let vtTrongSo = 0;
          // rows.forEach((row) => {
          //   let tmp = row[1] ? String(row[1]) : "";
          //   if (tmp === "Trọng số" || tmp === "Trọng số:") {
          //     return;
          //   }
          //   vtTrongSo += 1;
          // });

          rows = rows.slice(8);
          console.log(rows);
          rows = rows.map((item) => {
            return {
              msv: item[2],
              ho: item[3],
              ten: item[4],
              lop: item[5],
              diemChuyenCan: item[6],
              diemTrungBinhKiemTra: item[7],
              diemThiNghiemThucHanh: item[8],
              diemBaiTapLon: item[9],
              diemThi: item[10],
            };
          });
          setDataTable(rows);
        })
        .catch((error) => {
          console.error("Error reading file:", error);
          alert(
            "Có lỗi xảy ra khi đọc file. Vui lòng kiểm tra lại file và thử lại."
          );
        });
    }
  };

  return (
    <div className="container__import-score">
      {/* Header */}
      <div className="header__import-score">
        <div className="header__import-score-icon">
          <EditOutlined />
        </div>
        <div className="header__import-score-title">
          Nhập điểm môn học cho sinh viên
        </div>
      </div>

      {/* Content */}
      <div className="content__import-score">
        {/* Content-header */}
        <div className="content__import-score-header">
          <div className="content__import-score-search">
            <ImportScoreSearch setTerm={setTerm} setSubject={setSubject}/>
          </div>
          <div className="content__import-score-print">
            <button>
              <PrinterOutlined />
              <p style={{ marginLeft: 5 }}>In</p>
            </button>
          </div>
          <div className="content__import-score-import-file">
            <button onClick={handleButtonClick}>Upload File</button>
            <input
              id="file-upload"
              type="file"
              accept=".xlsx"
              ref={fileInputRef}
              style={{ display: "none" }}
              onChange={handleFileUpload}
            />
          </div>
        </div>

        {/* Content-table */}
        <h2 className="content__table-title">Bảng điểm môn học</h2>
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Số TT</th>
                <th>Mã SV</th>
                <th>Họ</th>
                <th>Tên</th>
                <th>Lớp</th>
                <th>Điểm CC</th>
                <th>Điểm TBKT</th>
                <th>Điểm TN-TH</th>
                <th>Điểm BTTL</th>
                <th>Điểm Thi</th>
              </tr>
            </thead>
            <tbody>
              {dataTable?.map((item, index) => (
                <tr key={index}>
                  {index === 0 ? (
                    <td colSpan={5}>Trọng số</td>
                  ) : (
                    <>
                      <td>{index + 1}</td>
                      <td>
                        <input
                          name="msv"
                          value={item.msv}
                          onChange={(e) => handleInputChange(index, e)}
                        />
                      </td>
                      <td>
                        <input
                          name="ho"
                          value={item.ho}
                          onChange={(e) => handleInputChange(index, e)}
                        />
                      </td>
                      <td>
                        <input
                          name="ten"
                          value={item.ten}
                          onChange={(e) => handleInputChange(index, e)}
                        />
                      </td>
                      <td>
                        <input
                          name="lop"
                          value={item.lop}
                          onChange={(e) => handleInputChange(index, e)}
                        />
                      </td>
                    </>
                  )}
                  <td>
                    <input
                      name="diemChuyenCan"
                      value={item.diemChuyenCan}
                      onChange={(e) => handleInputChange(index, e)}
                    />
                  </td>
                  <td>
                    <input
                      name="diemTrungBinhKiemTra"
                      value={item.diemTrungBinhKiemTra}
                      onChange={(e) => handleInputChange(index, e)}
                    />
                  </td>
                  <td>
                    <input
                      name="diemThiNghiemThucHanh"
                      value={item.diemThiNghiemThucHanh}
                      onChange={(e) => handleInputChange(index, e)}
                    />
                  </td>
                  <td>
                    <input
                      name="diemBaiTapLon"
                      value={item.diemBaiTapLon}
                      onChange={(e) => handleInputChange(index, e)}
                    />
                  </td>
                  <td>
                    <input
                      name="diemThi"
                      value={item.diemThi}
                      onChange={(e) => handleInputChange(index, e)}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <button
        style={{ marginBottom: 10, marginLeft: 1352 }}
        onClick={handleAddRow}
      >
        <PlusOutlined />
      </button>
      <button className="content__save-score" onClick={handleSaveScores}>
        Lưu điểm
      </button>
    </div>
  );
}

export default ImportScore;
