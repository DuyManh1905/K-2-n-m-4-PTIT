import { Select, Space } from 'antd'
import React, { useEffect, useState } from 'react'
import './importScoreSearch.css'
import { getAllSectionClass } from '../../service/hdvService'
function ImportScoreSearch({setTerm, setSubject}) {

  const [sectionClass, setSectionClass] = useState([])

  useEffect( () => {
    const fetch = () => {
      const res = getAllSectionClass("api/hdv/SectionClass")
      const newSectionClass = res.map( (item) => {
        return {
          "value": item.name,
          "label": item.name
        }
      })
      setSectionClass(newSectionClass)
    }
    fetch()
  },[])

  const handleSelectTerm = (value) => {
    setTerm(value)
  }
  const handleSelectSubject = (value) => {
    setSubject(value)
  }
  return (
    <div className='import__core-search'>
      <Space wrap>
            <Select
              defaultValue="Học kì 2 Năm học 2024-2025"
              style={{
                width: 320,
                height: 40
              }}
              onChange={handleSelectTerm}
              options={[
                {
                  value: "HK2/2024-2025",
                  label: "Học kì 2 Năm học 2024-2025",
                },
              ]}
            />
            <Select
              defaultValue=""
              onChange={handleSelectSubject}
              style={{
                width: 320,
                height: 40
              }}
              options={sectionClass}
            />
          </Space>
    </div>
  )
}
export default ImportScoreSearch