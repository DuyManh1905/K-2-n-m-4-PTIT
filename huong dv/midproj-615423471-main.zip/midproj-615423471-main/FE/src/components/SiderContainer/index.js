import React from 'react'
import SiderLogin from './SiderLogin'
import SiderFunction from './SiderFunction'

function SiderContainer() {
  return (
    <>
      <SiderLogin />
      <SiderFunction />
    </>
  )
}

export default SiderContainer