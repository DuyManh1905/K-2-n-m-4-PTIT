import React from 'react'
import {
  UserOutlined,
  LoginOutlined
} from '@ant-design/icons';
import './siderLogin.css'
import '../../assets/css/root.css'
import { Input } from 'antd';
function SiderLogin() {
  return (
    <div className='sider__login'>
      <div className='header__login'>
        <div className='header__login-left'>
          <UserOutlined style={{fontSize: 20}}/>
          <p style={{marginLeft: 10}}>ĐĂNG NHẬP</p>
        </div>
      </div>
      <div className='content__login'>
         <p className='account'>Tài khoản: B20DCGV666</p>
         <p className='fullName'>Họ và tên: Trần Văn Ninh</p>
      </div>
      <div className='footer__login'>
        <button className="footer__login-login">
          <div>
             <LoginOutlined />
          </div>
          <h3 style={{marginLeft: 10}}>Đăng nhập</h3>
        </button>
        <button className='footer__login-forger-password'>
            Đổi mật khẩu
        </button>
      </div>

    </div>
  )
}
export default SiderLogin