import React from 'react'
import {
  DoubleRightOutlined,
  RightOutlined,
} from '@ant-design/icons';
import './siderFunction.css'
import '../../assets/css/root.css'
import { Link } from 'react-router-dom';
function SiderFunction() {
  return (
    <div className="container__function">
      <div className='header__function'>
        <div className='header__function-icon'>
          <DoubleRightOutlined />
        </div>
        <div className='header__function-title'>
          Tính năng
        </div>
      </div>
      <div className='content__function'>
        <div className='content__function-child'>
          <Link to="import-score">
            <button className='content__function-child-btn'>
              <div className='content__function-input-score-icon'>
                  <RightOutlined /> 
              </div>
              <div className='content__function-input-score-title'>
                Nhập điểm môn học
              </div>
            </button>
          </Link>
        </div>
      </div>
    </div>
  )
}
export default SiderFunction