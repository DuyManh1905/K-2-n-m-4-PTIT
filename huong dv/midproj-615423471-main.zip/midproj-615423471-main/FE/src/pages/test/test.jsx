import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import "./ExcelToTableConverter.css";

const argbToRgb = (argb) => {
    if (!argb) return 'transparent'; // No color found or transparent
    // Excel uses ARGB format, slice to convert to standard RGB
    return `#${argb.slice(2)}`;
};

const ExcelToTableConverter = () => {
    const [tableData, setTableData] = useState(null);
    const [error, setError] = useState(null);

    const handleFileChange = (event) => {
        const file = event.target.files[0];
        if (!file) return;

        const allowedTypes = ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel'];
        if (!allowedTypes.includes(file.type)) {
            setError('Only .xlsx or .xls file formats are allowed');
            return;
        }

        setError(null);
        const reader = new FileReader();
        reader.readAsArrayBuffer(file);

        reader.onload = (event) => {
            const data = new Uint8Array(reader.result);
            const workbook = XLSX.read(data, { type: 'array', cellStyles: true });
            generateTable(workbook);
        };

        reader.onerror = () => {
            setError('Failed to read file!');
        };
    };

    const generateTable = (workbook) => {
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const range = XLSX.utils.decode_range(sheet['!ref']); // Get the range of the sheet
        const rows = [];
        for (let R = range.s.r; R <= range.e.r; ++R) {
            const row = [];
            let rowStyle = {}; // Style for the whole row
    
            for (let C = range.s.c; C <= range.e.c; ++C) {
                const cell_ref = XLSX.utils.encode_cell({r: R, c: C});
                const cell = sheet[cell_ref];
                const styles = {
                  style :  {
                    color: 'black', 
                    backgroundColor: 'transparent' 
                  }
                };
                if (cell && cell.s) {
                    if (cell.s.fill && cell.s.fill.fgColor && cell.s.fill.fgColor.rgb) {
                        console.log(cell.s.fill.fgColor.rgb)
                        styles.style.backgroundColor = `#${cell.s.fgColor.rgb}`;
                    }
                    else{
                        console.log("loi")
                    }
                    if (cell.s.font && cell.s.font.color && cell.s.font.color.rgb) {
                      styles.style.color = `#${cell.s.font.rgb}`;
                    }
                    // Apply the background color of the first cell to the entire row
                    if (C === range.s.c && cell.s.fill && cell.s.fill.fgColor && cell.s.fill.fgColor.rgb) {
                        rowStyle.backgroundColor = `#${cell.s.fgColor.rgb}`;
                    }
                }
                row.push(<td key={`${R}-${C}`} style={styles.style}>{cell ? cell.v : ''}</td>);
            }
            rows.push(<tr key={R} style={rowStyle}>{row}</tr>);
        }
        setTableData(<table className="table table-striped table-bordered">{rows}</table>);
    };
    

    

    return (
        <div className="container">
            <h2 className="text-center mt-4 mb-4">Convert Excel to HTML Table using JavaScript</h2>
            <div className="card">
                <div className="card-header"><b>Select Excel File</b></div>
                <div className="card-body">
                    <input style={{width: 300}} type="file" onChange={handleFileChange} />
                    {error && <div className="alert alert-danger">{error}</div>}
                </div>
            </div>
            <div id="excel_data" className="mt-5">
                {tableData}
            </div>
        </div>
    );
};

export default ExcelToTableConverter