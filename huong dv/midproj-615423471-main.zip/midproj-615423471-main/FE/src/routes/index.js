import ImportScore from "../components/ImportScore";
import LayoutDefault from "../LayoutDefault";
import ExcelToTableConverter from "../pages/import_score/ExcelToTableConverter";
export const routes = [
  {
    path: '/',
    element: <LayoutDefault />,
    children: [
      {
        path: 'import-score',
        element: <ImportScore />
      }
    ]
  },
  
]