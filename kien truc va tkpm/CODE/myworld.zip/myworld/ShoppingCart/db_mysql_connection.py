import mysql.connector

# mydb = mysql.connector.connect(
#     host="localhost",
#     user="root",
#     password="admin",
#     database="shoppingcart"
# )
#
# mycursor = mydb.cursor()
#
# # QUERY
# code = "CREATE DATABASE 'shoppingcart'"
#
# # RUN
# mycursor.excute(code)
