# hospital_Management_SAD
![image](https://github.com/dung2892002/hospital_Management_SAD/assets/148439963/3d8e417b-7870-4ed5-ba2f-42c59ee7cca3)
