from django.apps import AppConfig


class MedicalServiceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'medical_service'
